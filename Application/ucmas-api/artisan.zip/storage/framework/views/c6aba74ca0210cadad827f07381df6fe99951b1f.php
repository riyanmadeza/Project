<header class="main-header">
    <!-- Logo -->
    <a href="/" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>IT</b></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>Inven</b>Tory</span>
    </a>
    <!-- Navbar -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="<?php echo e(asset('assets')); ?>/dist/img/AdminLTELogo.png" class="user-image profilePicture" alt="User Image">
                        <span class="hidden-xs">rmadeza@gmail.com</span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <img src="<?php echo e(asset('assets')); ?>/dist/img/AdminLTELogo.png" class="img-circle profilePicture" alt="User Image">
                            <p>
                                rmadeza@gmail.com
                            </p>
                        </li>

                        <!-- Menu Footer-->

                        <li class="user-footer">

                            

                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    <!-- /.navbar -->
</header>
<?php /**PATH C:\Users\Yanza\OneDrive\Documents\GitHub\Project\Application\ucmas-api\resources\views/layouts/main-nav.blade.php ENDPATH**/ ?>